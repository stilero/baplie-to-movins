These are sample files for different server technologies that can help implement SWFUpload.

These samples may not be drop-in solutions for your application but may help you find the direction you need to solve your particular issue.