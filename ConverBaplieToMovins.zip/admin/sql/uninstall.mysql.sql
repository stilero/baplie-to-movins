DROP TABLE IF EXISTS #__convert_bapliemovins_settings;
